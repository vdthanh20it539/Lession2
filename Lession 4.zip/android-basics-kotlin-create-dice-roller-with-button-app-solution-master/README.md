Create an interactive Dice Roller app - Solution Code
=====================================================

Solution code for the Android Basics in Kotlin: Create an interactive Dice Roller app codelab.
Starter code for the Android Basics in Kotlin:  Add more conditional behavior in Kotlin codelab.

Introduction
------------
In this codelab, you build an Android app that rolls a dice and shows the result on screen.

Pre-requisites
--------------

You need to know:
- How to create and run a "Hello, World!" app in Android Studio.
- Familiar with using TextViews and ImageViews in an app.
- How to modify the attributes of a TextView in the Layout Editor.
- How to extract text into a string resource to make it easier to translate your app and reuse strings.
- Kotlin programming basics as taught in the previous codelabs.



Getting Started
---------------

1. Download and run the app.
